<?php
/* Smarty version 3.1.30, created on 2018-03-08 14:07:29
  from "C:\xampp\htdocs\mesprojets\Barry Thierno Aliou Zainoul SEN_FORAGE\view\consommation\consommation.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5aa1359154e539_26214703',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '12a90ab62e5b2249beb6d0545b02a0ff4d608b28' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\Barry Thierno Aliou Zainoul SEN_FORAGE\\view\\consommation\\consommation.html',
      1 => 1520514443,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5aa1359154e539_26214703 (Smarty_Internal_Template $_smarty_tpl) {
?>

<html>
<head>

    <meta charset="UTF-8">
    <title>page liste</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap-cerulean.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
    <style>
        h1{
            color: #40007d;
        }
    </style>
</head>
<style>
    .tabul{
        text-indent:400px;
    }
    .footer {
        margin-top: 20px;
        left: 0;
        bottom: 0;
        width: 100%;
        height:60px;
        background-color:#011d37;
        color: white;
        text-align:center;

    }
    a{
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 18px;
    ;

    }
</style>
<?php echo '<script'; ?>
 language="JavaScript">
    function verif(){
        return confirm("Voulez vous reelement supprimer cette Consommationt?");

    }
<?php echo '</script'; ?>
>
<body>

<div class="nav navbar-inverse">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/accueil"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" width="50" height="40"></a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
client/liste">Clients</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
village/liste">Village</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
compteur/liste">Compteur</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
abonnement/liste">Abonnement</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/liste">Consommation</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
facturation/liste">Facturation</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
reglement/liste">Reglement Facture</a></li>
            <li class="tabul"><a href="#">Deconnexion <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logout.jpg" width="40" height="40"></a></li>
        </ul>
    </div>
</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire d'enregistrement des consommations</div>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
            <div class="panel-body" style="color: green; background-color: #afd9ee">
                Consommation Enregistrée avec succes!
            </div>
            <?php } else { ?>
            Erreur d'insertion!
            <?php }?>
            <?php }?>
            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/add">
                <div class="form-group col-md-6">
                    <label class="control-label">Numero de compteur </label>
                    <select class="form-control"  name="num_compteur">

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['compteur']->value, 'c');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['c']->value) {
?>
                        <option value=".<?php echo $_smarty_tpl->tpl_vars['c']->value['id'];?>
."><?php echo $_smarty_tpl->tpl_vars['c']->value['num_compteur'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>

                </div>
                <div class="form-group col-md-6 ">

                    <label class="control-label">Volume de la consommation </label>
                    <input class="form-control" type="text" name="volume_conso" />
                </div>
                <div class="form-group col-md-6 ">
                    <label class="control-label">Volume consommation en lettre</label>
                    <input class="form-control" type="text" name="volume_conso_lettre" />
                </div>

                <div class="form-group col-md-6">
                    <label class="control-label">Date prélevement</label>
                    <input class="form-control" type="date" name="date_prelevement" />
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label">Mois</label>
                    <input class="form-control" type="text" name="mois" id=""/>
                </div>
                <div class="form-group col-md-6">
                    <label class="control-label">Prix par litre</label>
                    <input class="form-control" type="text" name="prix" id="d"/>
                </div>
                <div class="form-group col-md-12">

                    <label class="control-label">Client</label>
                    <select class="form-control" id="e" name="id_client">

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['client']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
                        <option value=".<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
."><?php echo $_smarty_tpl->tpl_vars['v']->value['nc'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>



                    </select>
                </div>
                <div class="form-group col-md-12">
                    <input class="btn btn-success" type="submit" name="valider" value="Valider"/>
                    <input class="btn btn-danger" type="reset" name="annuler" value="Annuler"/>
                </div>
            </form>
        </div>
    </div>
</div>
<div style="width: 450px;margin-top: 30px;margin-left: 600px;">
    <form action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/liste" method="get">
        <div class="input-group">
            <input name="motcle" id="btn-input" type="text" class="form-control input-sm-3" placeholder="Saisir le numero du compteur à rechercher ici..."/>
         <span class="input-group-btn">
             <input type="submit" class="btn btn-primary btn-md" id="btn-chat" value="rechercher" />

         </span>
        </div>
    </form>
</div>

</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:20px; ">
    <div class="panel panel-info">
        <div class="panel-heading">Liste Des Consommations</div>
        <?php if (isset($_smarty_tpl->tpl_vars['okk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Consommation Modifiée avec succes!!!!!
        </div>
        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucun changement
        </div>
        <?php }?>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['okkk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okkk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Consommation Supperimée avec succes!
        </div>
        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucune suppression Effectuée
        </div>
        <?php }?>
        <?php }?>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
            <table class="table table-bordered table-stripped" style="background-color: #a6e1ec; font-family: sans-serif; font-size: 14px ">
                <tr>

                    <th>Numero conso</th>
                    <th>Numero du Compteur</th>
                    <th>Volume de consommaion</th>
                    <th>Volume de consommaion en lettre</th>
                    <th>Date du prelevement</th>
                    <th>Mois</th>
                    <th>Editer</th>
                    <th>Supprimer</th>

                </tr>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['num_conso'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['num_compteur'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['volume_cons'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['volume_cons_lettre'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['date_prelevement'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['mois'];?>
</td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/edit&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['num_conso'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/modifier.png"></a> </td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/delete&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['num_conso'];?>
"onclick='verif()'><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/supprimer.png"></a> </td>
                </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


                <?php } else { ?>
                Liste vide
                <?php }?>
                <?php }?>
            </table>
        </div>

    </div>

</div>

<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/eaupotable.png" width="100%" height="0px;"/>

<div class="footer">
    <br/>
    <p>@2018 copyright all rights reserved Sen Forage</p>
    <br/>
</div>


</body>
</html>
<?php }
}
