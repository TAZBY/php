<?php
/* Smarty version 3.1.30, created on 2018-04-03 00:20:13
  from "C:\xampp\htdocs\mesprojets\GestionSalle\view\creneau\edit.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac2ac9d1ff060_46347193',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a70a79d8af8df8be118ba72d9cb0002f5b0d3c20' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\GestionSalle\\view\\creneau\\edit.html',
      1 => 1522707536,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac2ac9d1ff060_46347193 (Smarty_Internal_Template $_smarty_tpl) {
?>

<html>
<head>

    <meta charset="UTF-8">
    <title>page liste</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap-cerulean.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
    <style>
        h1{
            color: #40007d;
        }
    </style>
</head>
<style>
    .tabul{
        text-indent:400px;
    }
    .footer {
        margin-top: 100px;
        left: 0;
        bottom: 0;
        width: 100%;
        height:60px;
        background-color:#011d37;
        color: white;
        text-align:center;

    }
    a{
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 18px;
    ;

    }
</style>
<body>

<div class="nav navbar-inverse">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/accueil"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" width="50" height="40"></a></li>

            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
creneau/liste">Creneau</a></li>
            <li class="tabul"><a href="#">Deconnexion <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logout.jpg" width="40" height="40"></a></li>
        </ul>
    </div>
</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire De Modification</div>
        <div class="panel-body">

            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/update">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['modif']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Classe</label>
                    <input class="form-control" type="HIDDEN" name="id" id="id" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['idcreneau'];?>
"/>
                    <select class="form-control" id="exampleFormControlSelect1" name="idclasse" >
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['classes']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>

                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['idclasse'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nomclasse'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>

                </div>

                <div class="form-group col-md-6 ">
                    <label for="exampleFormControlSelect1">Nom salle</label>
                    <select class="form-control" id="d" name="idsalle">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['salles']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>

                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>
                </div>
                <div class="form-group col-md-12">
                    <label class="control-label">Date</label>
                    <input class="form-control" type="date" name="datecre"/>


                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure debut</label>
                    <select class="form-control" id="" name="hd">
                        <option>8 H</option>
                        <option>9 H</option>
                        <option>10 H</option>
                        <option>11 H</option>
                        <option>12 H</option>
                        <option>13 H</option>
                        <option>14 H</option>
                        <option>15 H</option>
                        <option>16 H</option>
                        <option>17 H</option>
                        <option>18 H</option>
                        <option>19 H</option>
                        <option>20 H</option>
                        <option>21 H</option>
                    </select>


                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure fin</label>
                    <select class="form-control" id="x" name="hf">
                        <option>8 H</option>
                        <option>9 H</option>
                        <option>10 H</option>
                        <option>11 H</option>
                        <option>12 H</option>
                        <option>13 H</option>
                        <option>14 H</option>
                        <option>15 H</option>
                        <option>16 H</option>
                        <option>17 H</option>
                        <option>18 H</option>
                        <option>19 H</option>
                        <option>20 H</option>
                        <option>21 H</option>
                    </select>

                </div>
                <div class="form-group col-md-12">
                    <input class="btn btn-success" type="submit" name="valider" value="Valider"/>
                    <input class="btn btn-danger" type="reset" name="annuler" value="Annuler"/>
                </div>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            </form>
        </div>
    </div>
</div>

<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/eaupotable.png" width="100%" height="0px;"/>
<!--<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
    <div class="panel panel-info">
        <div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
        <div class="panel-body">
            <div id="design_js">MODELE DEVELOPPE PAR Ngor SECK ! <h1>Version 1.0.1</h1></div>
        </div>
    </div>
</div>-->
<div class="footer">
    <br/>
    <p>@2018 copyright all rights reserved Sen Forage</p>
    <br/>
</div>


</body>
</html>
<?php }
}
