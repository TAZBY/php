<?php
/* Smarty version 3.1.30, created on 2018-03-03 22:28:26
  from "C:\xampp\htdocs\mesprojets\Barry Thierno Aliou Zainoul SEN_FORAGE\view\abonnement\abonnement.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5a9b137a670600_07426854',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1822ce5c0efef0beeb63fc1f7a11886d49f425c5' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\Barry Thierno Aliou Zainoul SEN_FORAGE\\view\\abonnement\\abonnement.html',
      1 => 1520112499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a9b137a670600_07426854 (Smarty_Internal_Template $_smarty_tpl) {
?>

<html>
<head>

    <meta charset="UTF-8">
    <title>page liste</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap-cerulean.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
    <style>
        h1{
            color: #40007d;
        }
    </style>
</head>
<style>
    .tabul{
        text-indent:400px;
    }
    .footer {
        margin-top: 20px;
        left: 0;
        bottom: 0;
        width: 100%;
        height:60px;
        background-color:#011d37;
        color: white;
        text-align:center;

    }
    a{
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 18px;
       ;

    }
</style>
<?php echo '<script'; ?>
 language="JavaScript">
    function verif(){
        return confirm("Voulez vous reelement supprimer ce Client?");

    }
<?php echo '</script'; ?>
>
<body>

<div class="nav navbar-inverse">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/accueil"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" width="50" height="40"></a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
client/liste">Clients</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
village/liste">Village</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
compteur/liste">Compteur</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
abonnement/liste">Abonnement</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
consommation/liste">Consommation</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
facturation/liste">Facturation</a></li>
            <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
reglement/liste">Reglement Facture</a></li>
            <li class="tabul"><a href="#">Deconnexion <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logout.jpg" width="40" height="40"></a></li>
        </ul>
    </div>
</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire D'ajout D'abonnements</div>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
            <div class="panel-body" style="color: green; background-color: #afd9ee">
            Abonnement ajouté avec succes!
            </div>
            <?php } else { ?>
            Erreur d'insertion!
            <?php }?>
            <?php }?>
            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
abonnement/add">
                <div class="form-group col-md-12">
                    <label class="control-label">Date D'abonnement</label>
                    <input class="form-control" type="DATE" name="dateA" id="date"/>


                </div>
                <div class="form-group col-md-6">

                    <label class="control-label">Client</label>
                    <select class="form-control" id="" name="idclient">

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['client']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
                        <option value=".<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
."><?php echo $_smarty_tpl->tpl_vars['v']->value['nc'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>



                    </select>
                </div>
                <div class="form-group col-md-6 ">
                    <label class="control-label">Compteur</label>
                    <select class="form-control" id="f" name="idcompteur">

                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['compteur']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
                        <option value=".<?php echo $_smarty_tpl->tpl_vars['v']->value['id'];?>
."><?php echo $_smarty_tpl->tpl_vars['v']->value['num_compteur'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>



                    </select>
                </div>
                <div class="form-group col-md-12">
                    <label class="control-label">Description De l'abonnement</label>
                    <input class="form-control" type="text" name="description" id="desc"/>


                </div>
                <div class="form-group col-md-12">
                    <input class="btn btn-success" type="submit" name="valider" value="Valider"/>
                    <input class="btn btn-danger" type="reset" name="annuler" value="Annuler"/>
                </div>
            </form>
        </div>
    </div>
</div>
<div style="width: 450px;margin-top: 30px;margin-left: 600px;">
    <form action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
abonnement/liste" method="get">
        <div class="input-group">
            <input name="motcle" id="btn-input" type="text" class="form-control input-sm-3" placeholder="Saisir le nom du client à rechercher ici..."/>
         <span class="input-group-btn">
             <input type="submit" class="btn btn-primary btn-md" id="btn-chat" value="rechercher" />

         </span>
            </div>
    </form>
</div>

</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:20px; ">
    <div class="panel panel-info">
        <div class="panel-heading">Liste Des Abonnements</div>
        <?php if (isset($_smarty_tpl->tpl_vars['okk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Abonnement Modifié avec succes!!!!!
        </div>
        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucun changement
        </div>
        <?php }?>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['okkk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okkk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Abonnement Supperimé avec succes!
        </div>
        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucune suppression Effectuée
        </div>
        <?php }?>
        <?php }?>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
            <table class="table table-bordered table-stripped" style="background-color: #a6e1ec; font-family: sans-serif; font-size: 14px ">
                <tr>

                    <th>id</th>
                    <th>Date Abonnement</th>
                    <th>Descriptions</th>
                    <th>client</th>
                    <th>Compteur</th>
                    <th>Editer</th>
                    <th>Supprimer</th>


                </tr>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['num_abonnement'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['date_abonnement'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['description_abonnement'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['nc'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['num_compteur'];?>
</td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/edit&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['num_abonnement'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/modifier.png"></a> </td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/delete&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['num_abonnement'];?>
"onclick='verif()'><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/supprimer.png"></a> </td>
                </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


            <?php } else { ?>
            Liste vide
            <?php }?>
            <?php }?>
            </table>
        </div>

    </div>

</div>

<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/eaupotable.png" width="100%" height="0px;"/>
<!--<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
    <div class="panel panel-info">
        <div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
        <div class="panel-body">
            <div id="design_js">MODELE DEVELOPPE PAR Ngor SECK ! <h1>Version 1.0.1</h1></div>
        </div>
    </div>
</div>-->
<div class="footer">
    <br/>
    <p>@2018 copyright all rights reserved Sen Forage</p>
    <br/>
</div>


</body>
</html>
<?php }
}
