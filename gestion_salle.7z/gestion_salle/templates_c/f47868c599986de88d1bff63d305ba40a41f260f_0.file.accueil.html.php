<?php
/* Smarty version 3.1.30, created on 2018-04-06 22:32:33
  from "C:\xampp\htdocs\mesprojets\gestion_salle\view\accueil\accueil.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac7d9613ee962_28342582',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f47868c599986de88d1bff63d305ba40a41f260f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\gestion_salle\\view\\accueil\\accueil.html',
      1 => 1522938948,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac7d9613ee962_28342582 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<!-- integration de javascript dans le moteur de rendu de vue Smarty -->
		
			<?php echo '<script'; ?>
 language=javascript>
			 function load_design() {
			   document.getElementById("design_js").style.color = "#40007d";
			 }

			<?php echo '</script'; ?>
>
		
	</head>
	<body onload="load_design()">
	<div class="container">
		<nav class="navbar navbar-inverse">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/index">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" alt="Logo" class="img-thumbnail" style="width:80px;">
					</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav">
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/add">Ajouter une salle</a></li>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/liste"> Liste des salles</a></li>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/addClasse">Ajouter une classe</a></li>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/liste">Liste des classes</a></li>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">Occuper une Salle</a></li>
						<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/Liste">Liste des salles occuppees</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</div>
	<div class="">
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logoiam.png" alt="logo" style=";
    min-width: 70%;
    min-height: 10%;
    height: 150px;" class="img-responsive center-block"/>
	</div>
	<br>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="thumbnail">
					<a href="#" target="_blank">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/imagesalle.jpg" alt="salle" style="width:100%;">
						<div class="caption">
							<p>Liste des salles.</p>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="thumbnail">
					<a href="#" target="_blank">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/imageclasse.jpg" alt="classe" style="width:100%; ">
						<div class="caption">
							<p>liste des classes</p>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-4">
				<div class="thumbnail">
					<a href="#" target="_blank">
						<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/listeoccuper.jpg" alt="Fjords" style="width:100%">
						<div class="caption">
							<p>Liste des salles occupees</p>
						</div>
					</a>
				</div>
			</div>
		</div>
	</div>
	</body>
</html><?php }
}
