<?php
/* Smarty version 3.1.30, created on 2018-04-05 17:38:46
  from "C:\xampp\htdocs\mesprojets\gestion_salle\view\salle\list.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac6430677b599_29379522',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a58107cb6d6f8d9d74fac9a501099edc9392ef34' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\gestion_salle\\view\\salle\\list.html',
      1 => 1522942606,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac6430677b599_29379522 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>liste des salle</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
</head>
<body>
<div class="container">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/index">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" alt="Logo" class="img-thumbnail" style="width:80px;">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/add">Ajouter une salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/liste"> Liste des salles</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/addClasse">Ajouter une classe</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/liste">Liste des classes</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">Occuper une Salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/Liste">Liste des salles occuppees</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="">
    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logoiam.png" alt="logo" style=";
    min-width: 70%;
    min-height: 10%;
    height: 150px;" class="img-responsive center-block"/>
</div>
<br>
<div style="width: 450px;margin-top: 30px;margin-left: 600px;">
    <form action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
salle/liste" method="get">
        <div class="input-group">
            <input name="motcle" id="btn-input" type="text" class="form-control input-sm-3"
                   placeholder="Saisir la Salle à rechercher ici..."/>
         <span class="input-group-btn">
             <input type="submit" class="btn btn-primary btn-md" id="btn-chat" value="rechercher" />

         </span>
        </div>
    </form>
</div>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:20px; ">
    <div class="panel panel-info">
        <div class="panel-heading">Liste Des Salles</div>
        <?php if (isset($_smarty_tpl->tpl_vars['okk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Salle Modifié avec succes!!!!!
        </div>
        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucun changement
        </div>
        <?php }?>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['okkk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okkk']->value != 0) {?>
        <div class="panel-body" style="color: green; background-color:#afd9ee">
            Salle Supprimé avec succes!
        </div>

        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucune suppression Effectuée
        </div>
        <?php }?>
        <?php }?>
        <?php if (isset($_smarty_tpl->tpl_vars['okkkk']->value)) {?>
        <?php if ($_smarty_tpl->tpl_vars['okkkk']->value != 0) {?>
        <div class="panel-body" style="color: #ffffff; background-color:darkred">
            Salle deja occupé!
        </div>

        <?php } else { ?>
        <div class="panel-body" style="color: green; background-color:#afd9ee; ">
            Aucun changement
        </div>
        <?php }?>
        <?php }?>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
            <table class="table table-bordered table-stripped" style="background-color: #a6e1ec; font-family: sans-serif; font-size: 14px ">
                <tr>
                    <th>Nom de la salle</th>
                    <th>Taille de la salle</th>
                    <th>Niveau de la salle</th>
                    <th>Type de la salle</th>
                    <th>Type de tableau</th>
                    <th>Video projecteur</th>
                    <th>Batiment</th>
                    <th>Action</th>
                    <th>Action</th>
                </tr>
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                <tr>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['nom'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['taille'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['niveausalle'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['typesalle'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['tableau'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['videoprojecteur'];?>
</td>
                    <td><?php echo $_smarty_tpl->tpl_vars['test']->value['batiment'];?>
</td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/edit&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['nom'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/modifier.png"></a></td>
                    <td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/delete&id=<?php echo $_smarty_tpl->tpl_vars['test']->value['nom'];?>
"><img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/icon/supprimer.png"></a></td>
                </tr>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                <?php } else { ?>
                Liste vide
                <?php }?>
                <?php }?>
            </table>
        </div>
    </div>
</div>
</body>
</html>
<?php }
}
