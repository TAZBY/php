<?php
/* Smarty version 3.1.30, created on 2018-04-05 17:26:09
  from "C:\xampp\htdocs\mesprojets\gestion_salle\view\creneau\edit.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac64011e626d2_56824839',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '59957ad052ae17f8371e7b84c81d671a33ae3945' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\gestion_salle\\view\\creneau\\edit.html',
      1 => 1522938988,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac64011e626d2_56824839 (Smarty_Internal_Template $_smarty_tpl) {
?>

<html>
<head>
    <meta charset="UTF-8">
    <title>page liste</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>

</head>
<body>
<div class="container">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/index">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" alt="Logo" class="img-thumbnail" style="width:80px;">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/add">Ajouter une salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/liste"> Liste des salles</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/addClasse">Ajouter une classe</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/liste">Liste des classes</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">Occuper une Salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/Liste">Liste des salles occuppees</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="">
    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logoiam.png" alt="logo" style=";
    min-width: 70%;
    min-height: 10%;
    height: 150px;" class="img-responsive center-block"/>
</div>
<br>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire De Modification</div>
        <div class="panel-body">

            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/update">
                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['modif']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Classe</label>
                    <input class="form-control" type="HIDDEN" name="id" id="id" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['idcreneau'];?>
"/>
                    <select class="form-control" id="exampleFormControlSelect1" name="idclasse" >
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['classes']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>

                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['idclasse'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nomclasse'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>

                </div>

                <div class="form-group col-md-6 ">
                    <label for="exampleFormControlSelect1">Nom salle</label>
                    <select class="form-control" id="d" name="idsalle">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['salles']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>

                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
</option>

                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>
                </div>
                <div class="form-group col-md-12">
                    <label class="control-label">Date</label>
                    <input class="form-control" type="date" name="datecre"/>


                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure debut</label>
                    <input class="form-control" type="time" name="hd"/>
                    <!--<select class="form-control" id="" name="hd">-->
                        <!--<option>8 H</option>-->
                        <!--<option>9 H</option>-->
                        <!--<option>10 H</option>-->
                        <!--<option>11 H</option>-->
                        <!--<option>12 H</option>-->
                        <!--<option>13 H</option>-->
                        <!--<option>14 H</option>-->
                        <!--<option>15 H</option>-->
                        <!--<option>16 H</option>-->
                        <!--<option>17 H</option>-->
                        <!--<option>18 H</option>-->
                        <!--<option>19 H</option>-->
                        <!--<option>20 H</option>-->
                        <!--<option>21 H</option>-->
                    <!--</select>-->


                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure fin</label>
                    <input class="form-control" type="time" name="hf"/>
                    <!--<select class="form-control" id="x" name="hf">-->
                        <!--<option>8 H</option>-->
                        <!--<option>9 H</option>-->
                        <!--<option>10 H</option>-->
                        <!--<option>11 H</option>-->
                        <!--<option>12 H</option>-->
                        <!--<option>13 H</option>-->
                        <!--<option>14 H</option>-->
                        <!--<option>15 H</option>-->
                        <!--<option>16 H</option>-->
                        <!--<option>17 H</option>-->
                        <!--<option>18 H</option>-->
                        <!--<option>19 H</option>-->
                        <!--<option>20 H</option>-->
                        <!--<option>21 H</option>-->
                    <!--</select>-->

                </div>
                <div class="form-group col-md-12">
                    <input class="btn btn-success" type="submit" name="valider" value="Valider"/>
                    <input class="btn btn-danger" type="reset" name="annuler" value="Annuler"/>
                </div>
                <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

            </form>
        </div>
    </div>
</div>
<!--<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
    <div class="panel panel-info">
        <div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
        <div class="panel-body">
            <div id="design_js">MODELE DEVELOPPE PAR Ngor SECK ! <h1>Version 1.0.1</h1></div>
        </div>
    </div>
</div>-->
<!--<div class="footer">-->
    <!--<br/>-->
    <!--<p>@2018 copyright all rights reserved Sen Forage</p>-->
    <!--<br/>-->
<!--</div>-->
</body>
</html>
<?php }
}
