<?php
function getConnexion(){
    $host = "localhost";
    $user = "root";
    $password = "";
    $dbname = "prospection";

    $connexion = mysqli_connect($host, $user, $password, $dbname);
    return $connexion;
}

function executeSql($sql){
    $execute = mysqli_query(getConnexion(), $sql);
    return $execute;
}