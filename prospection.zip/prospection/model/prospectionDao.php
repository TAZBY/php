<?php

function addIdentifiant($datePros,$nom,$prenom,$sex,$dateNaissance,$lieuNaissance,$nationalite,
$cellulaire,$email,$fonction,$niveauetude,$dernierEtabliFrequenter,$programmeInteresse,
$connuIam,$tempsPatienter,$jugeraccueil,$reponsesAttente,$suggestion){

    $sql = "INSERT INTO identification VALUES(NULL,
    '$datePros','$nom','$prenom','$sex','$dateNaissance','$lieuNaissance','$nationalite',
'$cellulaire','$email','$fonction','$niveauetude','$dernierEtabliFrequenter','$programmeInteresse',
'$connuIam','$tempsPatienter','$jugeraccueil','$reponsesAttente','$suggestion')";

    return executeSQL($sql);
}

function deleteIdentification($idProspect){
    $sql = "DELETE FROM identification WHERE idProspect = $idProspect";
    return executeSQL($sql);
}

function updateIdentification($idProspect,$datePros,$nom,$prenom,$sex,$dateNaissance,$lieuNaissance,$nationalite,
$cellulaire,$email,$fonction,$niveauetude,$dernierEtabliFrequenter,$programmeInteresse,
$connuIam,$tempsPatienter,$jugeraccueil,$reponsesAttente,$suggestion){

    $sql = "UPDATE identification SET 
                datePros = '$datePros',
                nom = '$nom',
                prenom = '$prenom',
                sex = '$sex',
                dateNaissance = '$dateNaissance',
                lieuNaissance = '$lieuNaissance',
                nationalite = '$nationalite',
                cellulaire  = '$cellulaire',
                email = '$email',
                fonction = '$fonction',
                niveauetude = '$niveauetude',
                dernierEtabliFrequenter = '$dernierEtabliFrequenter',
                programmeInteresse = '$programmeInteresse',
                connuIam = '$connuIam',
                tempsPatienter = '$tempsPatienter',
                jugeraccueil = '$jugeraccueil',
                reponsesAttente = '$reponsesAttente',
                suggestion = '$suggestion'
            WHERE idProspect = '$idProspect'";

    return executeSQL($sql);
}

function listIdentification(){
    $sql = "SELECT * FROM identification";

    return executeSQL($sql);
}
function recherche($motcle){
    $sql="select * from identification where programmeInteresse LIKE '%$motcle%'";
    return executeSQL($sql);

}

function getIdentificationById($idProspect){
    $sql = "SELECT * FROM identification WHERE idProspect = $idProspect";

    return executeSQL($sql);

}