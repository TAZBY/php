<?php
if(isset($_GET['page'])){
    require_once 'menu.php';
    switch($_GET['page']){
        case 'addIdentifiant':
            require_once 'menu.php';
            break;
        case 'listIdentification':
            require_once 'model/DB.php';
            require_once 'model/prospectionDao.php';
            $listes = listIdentification();
            require_once 'view/prospection/list.php';
            break;

        case 'deleteIdentification':
            break;
        
        case 'updateIdentification':
            require_once 'model/DB.php';

            require_once 'model/prospectionDao.php';

            $identification = getIdentificationById($_GET['id']);

            $ligne = mysqli_fetch_row($identification);

            require_once 'view/prospection/edit.php';
            break;
        }
}else{
    require_once 'menu.php';
}