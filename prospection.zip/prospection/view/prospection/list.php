<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Prospection</title>

    <!-- Bootstrap -->
    <link href="style/css_imp/bootstrap.css" rel="stylesheet">
    <link href="style/css_imp/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style/bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="style/bower_components/bootstrap-daterangepicker/daterangepicker.css">
    <link rel="stylesheet" href="style/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="style/plugins/iCheck/all.css">
    <link rel="stylesheet" href="style/plugins/timepicker/bootstrap-timepicker.min.css">
    <link rel="stylesheet" href="style/bower_components/select2/dist/css/select2.min.css">


    <link href="style/css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="style/jQueryAssets/jquery-1.11.1.min.js"></script>
</head>
<body>
<br/>
<div class="container">
    <img class="img-responsive center-block" src="style/css_imp/img/logoiam.png" width="250" height="100" alt=""/>
</div>
<div class="container">
    <div class="arrow">
        <div class="col-xs-12">
            <div class="modal fade" id="loginModal" data-keyboard="false" data-backdrop="static" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button class="close" data-dismiss="modal">&times;</button>
                            <h3 class="modal-title">Formulaire D'Ajout</h3>
                        </div>
                        <div class="modal-body">
                            <form action="controller/prospectionController.php" method="post">
                                <div class="form-group col-md-12">
                                    <label>Date:</label>

                                    <div class="input-group date">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control pull-right" id="datepicker" name="datePros">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Nom</label>
                                    <input class="form-control" placeholder="Entrer le nom" type="text" id="inputUserName" name="nom">

                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Prénom</label>
                                    <input class="form-control" placeholder="Entrer le nom" type="text" id="inputUserName" name="prenom">
                                </div>
                                <div class="form-group col-md-12">
                                    <label>
                                        <label>
                                            Sexe
                                        </label>
                                        <input type="radio" name="sexe" class="minimal" value="M" checked> M
                                    </label>
                                    <label>
                                        <input type="radio" name="sexe" class="minimal" value="F"> F
                                    </label>

                                </div>
                                <div class="form-group col-md-6">
                                    <label>Date de naissance</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </div>
                                        <input type="text" class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask placeholder="Entrer la date de la naissance" name="dateNaissance">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Lieu de naissance</label>
                                    <input class="form-control" placeholder="Entrer le lieu de naissance" type="text" id="inputUserName" name="lieuNaissance">
                                </div>
                                <div class="form-group col-md-6">
                                    <label>Cellulaire</label>

                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <input type="text" class="form-control" data-inputmask="'mask': '99-999-99-99'" data-mask name="cellulaire">
                                    </div>
                                    <!-- /.input group -->
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">E-mail</label>
                                    <input class="form-control" placeholder="Entrer votre mail" id="inputUserName" type="email" name="mail">
                                </div>
                                <div class="form-group col-md-6" required>
                                    <label for="exampleFormControlSelect1">Nationalité</label>
                                    <select class="form-control" id="" name="nationalite">

                                        <option value="France" selected="selected">Senegal </option>
                                        <option value="Afghanistan">Afghanistan </option>
                                        <option value="Afrique_Centrale">Afrique_Centrale </option>
                                        <option value="Afrique_du_sud">Afrique_du_Sud </option>
                                        <option value="Albanie">Albanie </option>
                                        <option value="Algerie">Algerie </option>
                                        <option value="Allemagne">Allemagne </option>
                                        <option value="Andorre">Andorre </option>
                                        <option value="Angola">Angola </option>
                                        <option value="Anguilla">Anguilla </option>
                                        <option value="Arabie_Saoudite">Arabie_Saoudite </option>
                                        <option value="Argentine">Argentine </option>
                                        <option value="Armenie">Armenie </option>
                                        <option value="Australie">Australie </option>
                                        <option value="Autriche">Autriche </option>
                                        <option value="Azerbaidjan">Azerbaidjan </option>
                                        <option value="Bahamas">Bahamas </option>
                                        <option value="Bangladesh">Bangladesh </option>
                                        <option value="Barbade">Barbade </option>
                                        <option value="Bahrein">Bahrein </option>
                                        <option value="Belgique">Belgique </option>
                                        <option value="Belize">Belize </option>
                                        <option value="Benin">Benin </option>
                                        <option value="Bermudes">Bermudes </option>
                                        <option value="Bielorussie">Bielorussie </option>
                                        <option value="Bolivie">Bolivie </option>
                                        <option value="Botswana">Botswana </option>
                                        <option value="Bhoutan">Bhoutan </option>
                                        <option value="Boznie_Herzegovine">Boznie_Herzegovine </option>
                                        <option value="Bresil">Bresil </option>
                                        <option value="Brunei">Brunei </option>
                                        <option value="Bulgarie">Bulgarie </option>
                                        <option value="Burkina_Faso">Burkina_Faso </option>
                                        <option value="Burundi">Burundi </option>
                                        <option value="Caiman">Caiman </option>
                                        <option value="Cambodge">Cambodge </option>
                                        <option value="Cameroun">Cameroun </option>
                                        <option value="Canada">Canada </option>
                                        <option value="Canaries">Canaries </option>
                                        <option value="Cap_vert">Cap_Vert </option>
                                        <option value="Chili">Chili </option>
                                        <option value="Chine">Chine </option>
                                        <option value="Chypre">Chypre </option>
                                        <option value="Colombie">Colombie </option>
                                        <option value="Comores">Colombie </option>
                                        <option value="Congo">Congo </option>
                                        <option value="Congo_democratique">Congo_democratique </option>
                                        <option value="Cook">Cook </option>
                                        <option value="Coree_du_Nord">Coree_du_Nord </option>
                                        <option value="Coree_du_Sud">Coree_du_Sud </option>
                                        <option value="Costa_Rica">Costa_Rica </option>
                                        <option value="Cote_d_Ivoire">Côte_d_Ivoire </option>
                                        <option value="Croatie">Croatie </option>
                                        <option value="Cuba">Cuba </option>
                                        <option value="Danemark">Danemark </option>
                                        <option value="Djibouti">Djibouti </option>
                                        <option value="Dominique">Dominique </option>
                                        <option value="Egypte">Egypte </option>
                                        <option value="Emirats_Arabes_Unis">Emirats_Arabes_Unis </option>
                                        <option value="Equateur">Equateur </option>
                                        <option value="Erythree">Erythree </option>
                                        <option value="Espagne">Espagne </option>
                                        <option value="Estonie">Estonie </option>
                                        <option value="Etats_Unis">Etats_Unis </option>
                                        <option value="Ethiopie">Ethiopie </option>
                                        <option value="Falkland">Falkland </option>
                                        <option value="Feroe">Feroe </option>
                                        <option value="Fidji">Fidji </option>
                                        <option value="Finlande">Finlande </option>
                                        <option value="France">France </option>
                                        <option value="Gabon">Gabon </option>
                                        <option value="Gambie">Gambie </option>
                                        <option value="Georgie">Georgie </option>
                                        <option value="Ghana">Ghana </option>
                                        <option value="Gibraltar">Gibraltar </option>
                                        <option value="Grece">Grece </option>
                                        <option value="Grenade">Grenade </option>
                                        <option value="Groenland">Groenland </option>
                                        <option value="Guadeloupe">Guadeloupe </option>
                                        <option value="Guam">Guam </option>
                                        <option value="Guatemala">Guatemala</option>
                                        <option value="Guernesey">Guernesey </option>
                                        <option value="Guinee">Guinee </option>
                                        <option value="Guinee_Bissau">Guinee_Bissau </option>
                                        <option value="Guinee equatoriale">Guinee_Equatoriale </option>
                                        <option value="Guyana">Guyana </option>
                                        <option value="Guyane_Francaise ">Guyane_Francaise </option>
                                        <option value="Haiti">Haiti </option>
                                        <option value="Hawaii">Hawaii </option>
                                        <option value="Honduras">Honduras </option>
                                        <option value="Hong_Kong">Hong_Kong </option>
                                        <option value="Hongrie">Hongrie </option>
                                        <option value="Inde">Inde </option>
                                        <option value="Indonesie">Indonesie </option>
                                        <option value="Iran">Iran </option>
                                        <option value="Iraq">Iraq </option>
                                        <option value="Irlande">Irlande </option>
                                        <option value="Islande">Islande </option>
                                        <option value="Israel">Israel </option>
                                        <option value="Italie">italie </option>
                                        <option value="Jamaique">Jamaique </option>
                                        <option value="Jan Mayen">Jan Mayen </option>
                                        <option value="Japon">Japon </option>
                                        <option value="Jersey">Jersey </option>
                                        <option value="Jordanie">Jordanie </option>
                                        <option value="Kazakhstan">Kazakhstan </option>
                                        <option value="Kenya">Kenya </option>
                                        <option value="Kirghizstan">Kirghizistan </option>
                                        <option value="Kiribati">Kiribati </option>
                                        <option value="Koweit">Koweit </option>
                                        <option value="Laos">Laos </option>
                                        <option value="Lesotho">Lesotho </option>
                                        <option value="Lettonie">Lettonie </option>
                                        <option value="Liban">Liban </option>
                                        <option value="Liberia">Liberia </option>
                                        <option value="Liechtenstein">Liechtenstein </option>
                                        <option value="Lituanie">Lituanie </option>
                                        <option value="Luxembourg">Luxembourg </option>
                                        <option value="Lybie">Lybie </option>
                                        <option value="Macao">Macao </option>
                                        <option value="Macedoine">Macedoine </option>
                                        <option value="Madagascar">Madagascar </option>
                                        <option value="Madère">Madère </option>
                                        <option value="Malaisie">Malaisie </option>
                                        <option value="Malawi">Malawi </option>
                                        <option value="Maldives">Maldives </option>
                                        <option value="Mali">Mali </option>
                                        <option value="Malte">Malte </option>
                                        <option value="Man">Man </option>
                                        <option value="Mariannes du Nord">Mariannes du Nord </option>
                                        <option value="Maroc">Maroc </option>
                                        <option value="Marshall">Marshall </option>
                                        <option value="Martinique">Martinique </option>
                                        <option value="Maurice">Maurice </option>
                                        <option value="Mauritanie">Mauritanie </option>
                                        <option value="Mayotte">Mayotte </option>
                                        <option value="Mexique">Mexique </option>
                                        <option value="Micronesie">Micronesie </option>
                                        <option value="Midway">Midway </option>
                                        <option value="Moldavie">Moldavie </option>
                                        <option value="Monaco">Monaco </option>
                                        <option value="Mongolie">Mongolie </option>
                                        <option value="Montserrat">Montserrat </option>
                                        <option value="Mozambique">Mozambique </option>
                                        <option value="Namibie">Namibie </option>
                                        <option value="Nauru">Nauru </option>
                                        <option value="Nepal">Nepal </option>
                                        <option value="Nicaragua">Nicaragua </option>
                                        <option value="Niger">Niger </option>
                                        <option value="Nigeria">Nigeria </option>
                                        <option value="Niue">Niue </option>
                                        <option value="Norfolk">Norfolk </option>
                                        <option value="Norvege">Norvege </option>
                                        <option value="Nouvelle_Caledonie">Nouvelle_Caledonie </option>
                                        <option value="Nouvelle_Zelande">Nouvelle_Zelande </option>
                                        <option value="Oman">Oman </option>
                                        <option value="Ouganda">Ouganda </option>
                                        <option value="Ouzbekistan">Ouzbekistan </option>
                                        <option value="Pakistan">Pakistan </option>
                                        <option value="Palau">Palau </option>
                                        <option value="Palestine">Palestine </option>
                                        <option value="Panama">Panama </option>
                                        <option value="Papouasie_Nouvelle_Guinee">Papouasie_Nouvelle_Guinee </option>
                                        <option value="Paraguay">Paraguay </option>
                                        <option value="Pays_Bas">Pays_Bas </option>
                                        <option value="Perou">Perou </option>
                                        <option value="Philippines">Philippines </option>
                                        <option value="Pologne">Pologne </option>
                                        <option value="Polynesie">Polynesie </option>
                                        <option value="Porto_Rico">Porto_Rico </option>
                                        <option value="Portugal">Portugal </option>
                                        <option value="Qatar">Qatar </option>
                                        <option value="Republique_Dominicaine">Republique_Dominicaine </option>
                                        <option value="Republique_Tcheque">Republique_Tcheque </option>
                                        <option value="Reunion">Reunion </option>
                                        <option value="Roumanie">Roumanie </option>
                                        <option value="Royaume_Uni">Royaume_Uni </option>
                                        <option value="Russie">Russie </option>
                                        <option value="Rwanda">Rwanda </option>
                                        <option value="Sahara Occidental">Sahara Occidental </option>
                                        <option value="Sainte_Lucie">Sainte_Lucie </option>
                                        <option value="Saint_Marin">Saint_Marin </option>
                                        <option value="Salomon">Salomon </option>
                                        <option value="Salvador">Salvador </option>
                                        <option value="Samoa_Occidentales">Samoa_Occidentales</option>
                                        <option value="Samoa_Americaine">Samoa_Americaine </option>
                                        <option value="Sao_Tome_et_Principe">Sao_Tome_et_Principe </option>
                                        <option value="Senegal">Senegal </option>
                                        <option value="Seychelles">Seychelles </option>
                                        <option value="Sierra Leone">Sierra Leone </option>
                                        <option value="Singapour">Singapour </option>
                                        <option value="Slovaquie">Slovaquie </option>
                                        <option value="Slovenie">Slovenie</option>
                                        <option value="Somalie">Somalie </option>
                                        <option value="Soudan">Soudan </option>
                                        <option value="Sri_Lanka">Sri_Lanka </option>
                                        <option value="Suede">Suede </option>
                                        <option value="Suisse">Suisse </option>
                                        <option value="Surinam">Surinam </option>
                                        <option value="Swaziland">Swaziland </option>
                                        <option value="Syrie">Syrie </option>
                                        <option value="Tadjikistan">Tadjikistan </option>
                                        <option value="Taiwan">Taiwan </option>
                                        <option value="Tonga">Tonga </option>
                                        <option value="Tanzanie">Tanzanie </option>
                                        <option value="Tchad">Tchad </option>
                                        <option value="Thailande">Thailande </option>
                                        <option value="Tibet">Tibet </option>
                                        <option value="Timor_Oriental">Timor_Oriental </option>
                                        <option value="Togo">Togo </option>
                                        <option value="Trinite_et_Tobago">Trinite_et_Tobago </option>
                                        <option value="Tristan da cunha">Tristan de cuncha </option>
                                        <option value="Tunisie">Tunisie </option>
                                        <option value="Turkmenistan">Turmenistan </option>
                                        <option value="Turquie">Turquie </option>
                                        <option value="Ukraine">Ukraine </option>
                                        <option value="Uruguay">Uruguay </option>
                                        <option value="Vanuatu">Vanuatu </option>
                                        <option value="Vatican">Vatican </option>
                                        <option value="Venezuela">Venezuela </option>
                                        <option value="Vierges_Americaines">Vierges_Americaines </option>
                                        <option value="Vierges_Britanniques">Vierges_Britanniques </option>
                                        <option value="Vietnam">Vietnam </option>
                                        <option value="Wake">Wake </option>
                                        <option value="Wallis et Futuma">Wallis et Futuma </option>
                                        <option value="Yemen">Yemen </option>
                                        <option value="Yougoslavie">Yougoslavie </option>
                                        <option value="Zambie">Zambie </option>
                                        <option value="Zimbabwe">Zimbabwe </option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Fonction</label>
                                    <input class="form-control" placeholder="Entrer la fonction" type="text" id="inputUserName" name="fonction">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="exampleFormControlSelect1">Niveau d'étude</label>
                                    <select class="form-control" id="" name="niveauetude">
                                        <option selected>Choisissez...</option>
                                        <option value="1er niveau">Bac</option>
                                        <option value="2eme niveau">Bac+1</option>
                                        <option value="3eme niveau">Bac+2</option>
                                        <option value="4eme niveau">Bac+3</option>
                                        <option value="5eme niveau">Bac+4</option>
                                        <option value="6eme niveau">Bac+5</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Dernier établissement frequenté</label>
                                    <input class="form-control" placeholder="Entrer l'établissement" type="text" id="inputUserName" name="dernierEtabliFrequenter">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="inputUserName">Quel programme vous intéresse ?</label>
                                    <input class="form-control" placeholder="Entrer le programme" type="text" id="inputUserName" name="programmeInteresse">
                                </div>
                                <br/>
                                <div class="form-group col-md-6 checkbox-inline">
                                    <br/>
                                    <label>Comment avez-vous connu l'IAM? ||  </label>
                                    <div class="checkbox">
                                        <input type="checkbox" class="flat-red" name="connuIam" value="medias"> Médias /


                                        <input type="checkbox" class="flat-red" name="connuIam" value="Amis et collègues"> Amis et Collègues /


                                        <input type="checkbox" class="flat-red" name="connuIam" value="Professeurs"> Professeurs /


                                        <input type="checkbox" class="flat-red" name="connuIam" value="Autres"> Autres
                                    </div>								<br/>


                                </div>
                                <br/>
                                <br/>
                                <div class="form-group col-md-6 checkbox-inline">
                                    <label>Combien de temps avez-vous patientém avant d'être reçu(e)?</label>
                                    <div class="checkbox">
                                        <input type="checkbox" class="flat-red" name="tempsPatienter" value="Aussitôt"> Aussitôt /

                                        <input type="checkbox" class="flat-red" name="tempsPatienter" value="Environ 1mn"> Environ 1mn /

                                        <input type="checkbox" class="flat-red" name="tempsPatienter" value="Environ 1 et 2mn"> Entre 1 et 2mn /

                                        <input type="checkbox" class="flat-red" name="tempsPatienter" value="plus de 5mn"> Plus de 5mn
                                        </label>

                                    </div>
                                </div>
                                <br/>
                                <br/>
                                <br/>
                                <div class="form-group col-md-12 checkbox-inline">


                                    <label>Comment jugez-vous l'accueil qui vous á été rèservé ?  </label>
                                    <div class="checkbox">
                                        <input type="checkbox" class="flat-red" name="jugeraccueil" value="Insatisfaisant"> Insatisfaisant /

                                        <input type="checkbox" class="flat-red" name="jugeraccueil" value="Peu satisfaisant"> Peu Satisfaisant /

                                        <input type="checkbox" class="flat-red" name="jugeraccueil" value="Satisfaisant"> Satisfaisant /

                                        <input type="checkbox" class="flat-red" name="jugeraccueil" value=" Très Satisfaisant"> Très Satisfaisant


                                    </div>
                                    <br/>
                                    <div class="form-group col-md-12">
                                        <label>
                                            <label>
                                                Avons-nous répondu a vos attentes ?
                                            </label>
                                            <input type="radio" name="r1" class="minimal" name="reponsesAttente" value="oui"> Oui
                                        </label>
                                        <label>
                                            <input type="radio" name="r1" class="minimal" name="reponsesAttente" value="non"> Nom
                                        </label>

                                    </div>
                                    <div class="form-group col-md-12">
                                        <label for="inputUserName">Suggestion</label>
                                        <textarea class="form-control" rows="5" name="suggestion"></textarea>
                                    </div>

                                </div>
                                <div class="btn-group-justified">

                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-primary "type="submit" name="enregistrer">Enregistrer</button>
                                    <button class="btn btn-primary" data-dismiss="modal">Fermer</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<br/>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div id="accordion" class="panel-group">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h4 class="panel-title text-center text-uppercase">
                            <a href="#panelBodyThree" data-toggle="collapse" data-parent="#accordion">
                                Prospections <span class="glyphicon glyphicon-arrow-down"></span>
                            </a>
                        </h4>
                    </div>
                    <div id="panelBodyThree" class="panel-collapse collapse">
                        <div class="panel-body">
                            <button class="btn btn-default btn btn-sm btn-primary pull-left" data-target="#loginModal" data-toggle="modal"><span class="glyphicon glyphicon-user plu"></span> <span class="glyphicon glyphicon-plus"></span> ADD </button>
                        </div>

                    <div class="panel-body">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title text-center text-uppercase">Liste des Prospecteurs </h4>
                            </div>
                            <br/>
                            <div class="table-responsive">
                                <table id="example1" class="table table-hover table-bordered table-responsive pre">
                                    <thead>
                                    <tr>
                                        <td>Numero</td>
                                        <td>Date</td>
                                        <td>Nom</td>
                                        <td>Prénom</td>
                                        <td>sexe</td>
                                        <td>Date de naissance</td>
                                        <td>Lieu de Naissance</td>
                                        <td>Nationalité</td>
                                        <td>Cellulaire</td>
                                        <td>E-mail</td>
                                        <td>Fonction</td>
                                        <td>Niveau d'étude</td>
                                        <td>Dernier établissement frequenté</td>
                                        <td>Quel programme vous intéresse</td>
                                        <td>Comment avez_vous connu IAM</td>
                                        <td>Combien de temps avez-vous patienté avant d'être reçu(e)</td>
                                        <td>Comment juges_vous l'accueil qui vous à été reservé</td>
                                        <td>Avons-nous repondu à attentes</td>
                                        <td>Suggestions</td>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                    while($serveur=mysqli_fetch_row($listes))
                                    {
                                        echo "<tr>
                       <td>$serveur[0]</td>
                       <td>$serveur[1]</td>
                       <td>$serveur[2]</td>
                       <td>$serveur[3]</td>
                       <td>$serveur[4]</td>
                       <td>$serveur[5]</td>
                       <td>$serveur[6]</td>
                       <td>$serveur[7]</td>
                       <td>$serveur[8]</td>
                       <td>$serveur[9]</td>
                       <td>$serveur[10]</td>
                       <td>$serveur[11]</td>
                       <td>$serveur[12]</td>
                       <td>$serveur[13]</td>
                       <td>$serveur[14]</td>
                       <td>$serveur[15]</td>
                       <td>$serveur[16]</td>
                       <td>$serveur[17]</td>
                       <td>$serveur[18]</td>
                       <td><a href='?page=updateIdentification&id=$serveur[0]'>Editer</a> </td>
                       <td><a href='controller/prospectionController.php?id=$serveur[0]'>Supprimer</a> </td>
                   </tr>";
                                    }
                                    ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
</div>
<br/>
<br/>
<div class="panel-footer text-primary text-uppercase navbar-fixed-bottom pull-left">
    <span class="badge">Dreamers.tech.com</span> IAM copyright © tous droits réservés
    <div class="list-inline pull-right">
        <a href="#" class="text-uppercase text-danger small" title="Nous sommes des êtudiants de troisiéme anneé á IAM passionné de l'informatique" data-toggle="tooltip" id="propos"><kbd> A propos <span class="glyphicon glyphicon-user"></span></kbd></a>
        <a href="#" class="small text-uppercase text-danger"><kbd> contacté <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span></kbd></a>
    </div>
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="style/js/jquery-1.11.3.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="style/js/bootstrap.js"></script>
<script src="style/css_imp/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="style/css_imp/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>


<script src="style/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="style/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="style/bower_components/select2/dist/js/select2.full.min.js"></script>
<!-- InputMask -->
<script src="style/plugins/input-mask/jquery.inputmask.js"></script>
<script src="style/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="style/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="style/bower_components/moment/min/moment.min.js"></script>
<script src="style/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="style/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- bootstrap color picker -->
<script src="style/bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="style/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll -->
<script src="style/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="style/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="style/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->

<script>
    $(function () {
        //Initialize Select2 Elements
        $('.select2').select2()

        //Datemask dd/mm/yyyy
        $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
        //Datemask2 mm/dd/yyyy
        $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
        //Money Euro
        $('[data-mask]').inputmask()

        //Date range picker
        $('#reservation').daterangepicker()
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A' })
        //Date range as a button
        $('#daterange-btn').daterangepicker(
            {
                ranges   : {
                    'Today'       : [moment(), moment()],
                    'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month'  : [moment().startOf('month'), moment().endOf('month')],
                    'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                },
                startDate: moment().subtract(29, 'days'),
                endDate  : moment()
            },
            function (start, end) {
                $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
            }
        )

        //Date picker
        $('#datepicker').datepicker({
            autoclose: true
        })

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass   : 'iradio_minimal-blue'
        })
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass   : 'iradio_minimal-red'
        })
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass   : 'iradio_flat-green'
        })

        //Colorpicker
        $('.my-colorpicker1').colorpicker()
        //color picker with addon
        $('.my-colorpicker2').colorpicker()

        //Timepicker
        $('.timepicker').timepicker({
            showInputs: false
        })
    })
</script>

<script type="text/javascript">
    $(function() {
        $("#propos").tooltip;
    });
</script>

<script>
    $(function () {
        $('#example1').DataTable({
            'paging'      : true,
            'lengthChange': true,
            'searching'   : true,
            'ordering'    : true,
            'info'        : true,
            'autoWidth'   : false,
            'language' :{
                "search": "Recherche : ",
                "sZeroRecords":"Aucune donnée trouver ",
                "sLengthMenu": "Afficher _MENU_ par page",
                "sInfo": "Affichage de _START_ à _END_ , total résultat _TOTAL_ ",
                "infoEmpty": "Pas de donnée á afficher",
                "infoFiltered": " - filtrer sur _MAX_ total lignes",
                "paginate": {
                    "next": "Suivante",
                    "previous": "Précédente"
                }
            }

        })
    })
</script>
</body>
</html>
