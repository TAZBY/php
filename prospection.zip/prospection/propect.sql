-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  jeu. 30 août 2018 à 21:27
-- Version du serveur :  5.6.35
-- Version de PHP :  7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Base de données :  `prospect`
--

-- --------------------------------------------------------

--
-- Structure de la table `identification`
--

CREATE TABLE `identification` (
  `idProspect` int(11) NOT NULL,
  `datePros` date NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `dateNaissance` date NOT NULL,
  `lieuNaissance` varchar(50) NOT NULL,
  `nationalite` varchar(50) NOT NULL,
  `cellulaire` varchar(20) NOT NULL,
  `fax` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `fonction` varchar(40) NOT NULL,
  `niveauetude` varchar(40) NOT NULL,
  `dernierEtabliFrequenter` varchar(40) NOT NULL,
  `programmeInteresse` varchar(80) NOT NULL,
  `connuIam` varchar(50) NOT NULL,
  `tempsPatienter` varchar(50) NOT NULL,
  `jugeraccueil` varchar(50) NOT NULL,
  `reponsesAttente` varchar(50) NOT NULL,
  `suggestion` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `identification`
--
ALTER TABLE `identification`
  ADD PRIMARY KEY (`idProspect`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `identification`
--
ALTER TABLE `identification`
  MODIFY `idProspect` int(11) NOT NULL AUTO_INCREMENT;