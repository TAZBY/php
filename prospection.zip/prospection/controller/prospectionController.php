<?php
    require_once '../model/DB.php';
    require_once '../model/prospectionDao.php';

    if(isset($_POST['enregistrer'])){
                $datePros = $_POST['datePros'];
                $nom = $_POST['nom'];
                $prenom = $_POST['prenom'];
                $sexe = $_POST['sexe'];
                $dateNaissance = $_POST['dateNaissance'];
                $lieuNaissance = $_POST['lieuNaissance'];
                $nationalite = $_POST['nationalite'];
                $cellulaire  = $_POST['cellulaire'];
                $email = $_POST['mail'];
                $fonction = $_POST['fonction'];
                $niveauetude = $_POST['niveauetude'];
                $dernierEtabliFrequenter = $_POST['dernierEtabliFrequenter'];
                $programmeInteresse = $_POST['programmeInteresse'];
                $connuIam = $_POST['connuIam'];
                $tempsPatienter = $_POST['tempsPatienter'];
                $jugeraccueil = $_POST['jugeraccueil'];
                $reponsesAttente = $_POST['reponsesAttente'];
                $suggestion = $_POST['suggestion'];
       
    addIdentifiant($datePros,$nom,$prenom,$sexe,$dateNaissance,$lieuNaissance,$nationalite,
            $cellulaire,$email,$fonction,$niveauetude,$dernierEtabliFrequenter,$programmeInteresse,
            $connuIam,$tempsPatienter,$jugeraccueil,$reponsesAttente,$suggestion);
    $base_url = "http://localhost/mesprojets/prospection/";
    header("location:$base_url?page=listIdentification");
    }

    if(isset($_GET['id'])){
        deleteIdentification($_GET['id']);
        $base_url = "http://localhost/mesprojets/prospection/";
        header("location:$base_url?page=updateIdentification");
    }

    if(isset($_POST['modifierIdentification'])){
        $datePros = $_POST['datePros'];
        $nom = $_POST['nom'];
        $prenom = $_POST['prenom'];
        $sexe = $_POST['sexe'];
        $dateNaissance = $_POST['dateNaissance'];
        $lieuNaissance = $_POST['lieuNaissance'];
        $nationalite = $_POST['nationalite'];
        $cellulaire  = $_POST['cellulaire'];
        $email = $_POST['mail'];
        $fonction = $_POST['fonction'];
        $niveauetude = $_POST['niveauetude'];
        $dernierEtabliFrequenter = $_POST['dernierEtabliFrequenter'];
        $programmeInteresse = $_POST['programmeInteresse'];
        $connuIam = $_POST['connuIam'];
        $tempsPatienter = $_POST['tempsPatienter'];
        $jugeraccueil = $_POST['jugeraccueil'];
        $reponsesAttente = $_POST['reponsesAttente'];
        $suggestion = $_POST['suggestion'];
                updateIdentification($idProspect,$datePros,$nom,$prenom,$sexe,$dateNaissance,$lieuNaissance,$nationalite,
                $cellulaire,$email,$fonction,$niveauetude,$dernierEtabliFrequenter,$programmeInteresse,
                $connuIam,$tempsPatienter,$jugeraccueil,$reponsesAttente,$suggestion);

        $base_url = "http://localhost/mesprojets/prospection/";
    header("location:$base_url?page=listIdentification");
    }