<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
class facturation extends Controller
{
    public function __construct()
    {
        parent::__construct();
        //Appel du model
        require_once 'model/facturationDB.php';
    }

    //A noter que toutes les views doivent être créées dans le dossier view/test
    //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
    public function index()
    {
        return $this->view->load("test/index");
    }

    public function liste()
    {
        //Instanciation du model
        $tdb = new facturationDB();

        if (isset($_GET['motcle'])) {
            $data['tests'] = $tdb->RechFacture($_GET['motcle']);
            return $this->view->load("facturation/facturation", $data);
        } else {

            $data['tests'] = $tdb->listeFacture();
            return $this->view->load("facturation/facturation",$data);
        }
    }

    public function facture(){
        //Instanciation du model
        $tdb = new facturationDB();
        if (isset($_GET['id'])) {
            $data['tests'] = $tdb->Facture($_GET['id']);
            return $this->view->load("facturation/facture", $data);
        }
    }
      public  function edit()
        {
            //Instanciation du model
            $tdb = new facturationDB();

            $data['modif'] = $tdb->getFactureRef($_GET['id']);

            return $this->view->load("facturation/edit", $data);

        }

       public function delete()
        {
            //Instanciation du model
            $tdb = new facturationDB();

            $okkk = $tdb->deleteFacture($_GET['id']);
            $data['okkk'] = $okkk;
            $data['tests'] = $tdb->listeAbonnement();

            return $this->view->load("abonnement/abonnement", $data);

        }


        public function add()
        {
            //Instanciation du model
            $tdb = new facturationDB();
            //Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if (isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                if (!empty($prix) && !empty($date_facturation) && !empty($num_abonnement) && !empty($num_conso)) {
                    $ok = $tdb->addfacture($prix, $date_facturation, $num_conso, $num_abonnement);
                    $data['ok'] = $ok;
                }
            }
            $data['abonnement'] = $tdb->listeAbonnement();
            $data['consommation'] = $tdb->listeConso();
            $data['tests'] = $tdb->listeFacture();
            return $this->view->load("facturation/facturation", $data);
        }




        public function reglement()
        {
            //Instanciation du model
            $tdb = new facturationDB();
            if (isset($_POST['regler'])) {
                extract($_POST);
                if (!empty($mv) && !empty($etat) && !empty($num_conso)) {
                    $okk = $tdb->addreglement($mv, $num_conso);
                    $data['okk'] = $okk;
                    $tdb->updateConsommation($num_conso,$etat);

                }
            }

            $data['tests'] = $tdb->listeFacture();
            return $this->view->load("facturation/facturation",$data);
        }



}
?>