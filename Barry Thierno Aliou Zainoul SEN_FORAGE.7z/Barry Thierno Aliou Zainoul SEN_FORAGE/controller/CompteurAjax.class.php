<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class CompteurAjax extends Controller{
        public function __construct(){
            parent::__construct();
            //Appel du model
            require_once 'model/CompteurDB.php';
        }

		//A noter que toutes les views doivent être créées dans le dossier view/test
        //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
        public function index(){
            return $this->view->load("compteur/compteurAjax");
        }


		public function fetch(){
            $tdb = new CompteurDB();
            $output='';
            $query='';
            if(isset($_POST['query'])){
                  $query=$this->$_POST['query'];
                }

            $data['tests'] = $tdb->fetch_data($query);
            $output .='
             <table class="table table-bordered table-stripped" style="background-color: #a6e1ec; font-family: sans-serif; font-size: 14px ">
                <tr>

                    <th>ID du compteur</th>
                    <th>Numero du compteur</th>
                    <th>Volume total par Compteur</th>

                </tr>

            ';
            if($data > 0){
                foreach($data['tests'] as $row){
                    $output .='
                    <tr>
                    <td>'.$row["id"].'</td>
                    <td>'.$row["num_compteur"].'</td>
                    <td>'.$row["volume_cons"].'</td>
</tr>
                    ';
                }
            }
            else{
                $output .='
                 <tr>
                <th>Aucune donnee trouvée</th>
                </tr>

                ';
            }

            $output .='</table>';
            echo $output;
        }
        public function edit(){
            //Instanciation du model
            $tdb = new CompteurDB();

                $data['modif']=$tdb->getCompteurRef($_GET['id']);
                return $this->view->load("compteur/edit",$data);

        }
        public function delete(){
            //Instanciation du model
            $tdb = new CompteurDB();
            $okkk=$tdb->deleteCompteur($_GET['id']);
            $data['okkk'] = $okkk;
            $data['tests'] = $tdb->listeCompteur();
            return $this->view->load("compteur/compteur",$data);

        }


        public function add(){
			//Instanciation du model
            $tdb = new CompteurDB();
			//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                if(!empty($nc) ) {
                    $ok = $tdb->addCompteur($nc,'0');
                    $data['ok'] = $ok;
                }
            }
            $data['tests'] = $tdb->listeCompteur();
            return $this->view->load("compteur/compteur",$data);
        }
		public function update(){
			//Instanciation du model
            $tdb = new CompteurDB();
            if(isset($_POST['modifier'])){
                extract($_POST);
                if(!empty($id) && !empty($nc))
                {
                    $okk = $tdb->updateCompteur($id,$nc);
                    $data['okk'] = $okk;
                }
            }
            $data['tests'] = $tdb->listeCompteur();
            return $this->view->load("compteur/compteur",$data);

        }
    }
?>