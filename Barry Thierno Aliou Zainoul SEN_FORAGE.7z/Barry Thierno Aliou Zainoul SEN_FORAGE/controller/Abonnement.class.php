<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class Abonnement extends Controller{
        public function __construct(){
            parent::__construct();
            //Appel du model
            require_once 'model/AbonnementDB.php';
        }

		//A noter que toutes les views doivent être créées dans le dossier view/test
        //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
        public function index(){
            return $this->view->load("test/index");
        }

		public function liste(){
            //Instanciation du model
            $tdb = new AbonnementDB();

            if(isset($_GET['motcle'])){
                $data['client'] = $tdb->liste_Client();
                $data['compteur'] = $tdb->liste_Compteur();
                $data['tests']=$tdb->RechAbonnement($_GET['motcle']);
                return $this->view->load("abonnement/abonnement",$data);
            }
            else{
                $data['client'] = $tdb->liste_Client();
                $data['compteur'] = $tdb->liste_Compteur();
                $data['tests'] = $tdb->listeAbonnement();
            return $this->view->load("abonnement/abonnement",$data);
            }

        }
        public function edit(){
            //Instanciation du model
            $tdb = new AbonnementDB();

                $data['modif']=$tdb->getAbonnementRef($_GET['id']);
                $data['client'] = $tdb->liste_Client();
                $data['compteur'] = $tdb->liste_Compteur();
                return $this->view->load("abonnement/edit",$data);

        }
        public function delete(){
            //Instanciation du model
            $tdb = new AbonnementDB();

            $okkk=$tdb->deleteAbonnement($_GET['id']);
            $data['okkk'] = $okkk;
            $data['tests'] = $tdb->listeAbonnement();

            return $this->view->load("abonnement/abonnement",$data);

        }


        public function add(){
			//Instanciation du model
            $tdb = new AbonnementDB();
			//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                if(!empty($dateA) && !empty($description) && !empty($idclient) &&  !empty($idcompteur) ) {
                    $ok = $tdb->addAbonnement($dateA,$description,$idclient,$idcompteur);
                    $data['ok'] = $ok;
                }
            }
            $data['client'] = $tdb->liste_Client();
            $data['compteur'] = $tdb->liste_Compteur();
            $data['tests'] = $tdb->listeAbonnement();
            return $this->view->load("abonnement/abonnement", $data);
        }
		public function update(){
			//Instanciation du model
            $tdb = new AbonnementDB();
            if(isset($_POST['modifier'])){
                extract($_POST);
                if(!empty($id) && !empty($dateA) && !empty($description) && !empty($idclient) &&  !empty($idcompteur) ) {
                    $okk = $tdb->updateAbonnement($id,$dateA,$description,$idclient,$idcompteur);
                    $data['okk'] = $okk;
                }
            }
            $data['client'] = $tdb->liste_Client();
            $data['compteur'] = $tdb->liste_Compteur();
            $data['tests'] = $tdb->listeAbonnement();
            return $this->view->load("abonnement/abonnement", $data);
        }
        
    }
?>