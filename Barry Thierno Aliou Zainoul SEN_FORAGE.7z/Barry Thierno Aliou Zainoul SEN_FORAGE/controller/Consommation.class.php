<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
class Consommation extends Controller{
    public function __construct(){
        parent::__construct();
        //Appel du model
        require_once 'model/ConsommationDB.php';
        require_once 'model/CompteurDB.php';
    }

    //A noter que toutes les views doivent �tre cr��es dans le dossier view/test
    //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider � mieux comprendre
//    public function index(){
//        return $this->view->load("test/index");
//    }
//
//    public function getID($id){
//        $data['ID'] = $id;
//
//        return $this->view->load("test/get_id", $data);
//    }
//
//    public function get($id){
//        //Instanciation du model
//        $tdb = new TestDB();
//
//        $data['test'] = $tdb->getTestRef($id);
//        return $this->view->load("test/get", $data);
   // }
    public function liste(){
        //Instanciation du model
        $tdb = new ConsommationDB();

        if(isset($_GET['motcle'])){
            $data['compteur'] = $tdb->listeCompteur();
            $data['client'] = $tdb->liste_Client();
            $data['tests']=$tdb->RechConso($_GET['motcle']);
            return $this->view->load("consommation/consommation",$data);
        }
        else{
            $data['compteur'] = $tdb->listeCompteur();
            $data['client'] = $tdb->liste_Client();
            $data['tests'] = $tdb->listeConso();
            return $this->view->load("consommation/consommation",$data);
        }

    }
    public function edit(){
        //Instanciation du model
        $tdb = new ConsommationDB();

        $okk=$data['modif']=$tdb->getConsoRef($_GET['id']);
        $data['okk'] = $okk;
        $data['compteur'] = $tdb->listeCompteur();
        return $this->view->load("consommation/edit",$data);

    }
    public function delete(){
        //Instanciation du model
        $tdb = new ConsommationDB();

        $okkk=$tdb->deleteConso($_GET['id']);
        $data['okkk'] = $okkk;
        $data['tests'] = $tdb->listeConso();

        return $this->view->load("consommation/consommation",$data);

    }



    public function add(){
        //Instanciation du model
        $tdb = new ConsommationDB();
        $tbd=new CompteurDB();
        //R�cup�ration des donn�es qui viennent du formulaire view/test/add.html (� cr�er)
        if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
        {
            extract($_POST);
            if(!empty($num_compteur) && !empty($volume_conso) &&  !empty($volume_conso_lettre) &&  !empty($date_prelevement)
                &&  !empty($mois) &&  !empty($prix) &&  !empty($id_client) ) {
                //$ok = $tdb->addConso($num_compteur,$volume_conso,$volume_conso_lettre,$date_prelevement,$mois,$prix,'non payee',$id_client);
               // $data['ok'] = $ok;
                $tbd->updateCompt($num_compteur,$volume_conso);

              }
        }

        $data['tests'] = $tdb->listeConso();
        $data['compteur'] = $tdb->listeCompteur();
        return $this->view->load("consommation/consommation", $data);
    }
    public function update(){
        //Instanciation du model
        $tdb = new ConsommationDB();
        if(isset($_POST['valider'])){
            extract($_POST);
            if(!empty($num_conso) && !empty($id) && !empty($volume_conso) &&  !empty($volume_conso_lettre)
                &&  !empty($date_prelevement)
                &&  !empty($mois)) {
                $okk = $tdb->updateConso($num_conso,$volume_conso,$volume_conso_lettre,$date_prelevement,$mois,$id);
                $data['okk'] = $okk;
            }
        }
        $data['tests'] = $tdb->listeConso();
        $data['village'] = $tdb->listeCompteur();
        return $this->view->load("consommation/consommation", $data);
    }

}
?>