<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class Village extends Controller{
        public function __construct(){
            parent::__construct();
            //Appel du model
            require_once 'model/VillageDB.php';
        }

		//A noter que toutes les views doivent être créées dans le dossier view/test
        //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
        public function index(){
            return $this->view->load("test/index");
        }

        public function getID($id){
            $data['ID'] = $id;

            return $this->view->load("test/get_id", $data);
        }
        
        public function get($id){
            //Instanciation du model
            $tdb = new TestDB();

            $data['test'] = $tdb->getTestRef($id);
            return $this->view->load("test/get", $data);
        }
		public function liste(){
            //Instanciation du model
            $tdb = new VillageDB();

            if(isset($_GET['motcle'])){

                $data['tests']=$tdb->RechVillage($_GET['motcle']);
                return $this->view->load("village/village",$data);
            }
            else{
                $data['tests'] = $tdb->listeVillage();
                return $this->view->load("village/village",$data);
            }

        }
        public function edit(){
            //Instanciation du model
            $tdb = new VillageDB();

                $data['modif']=$tdb->getVillageRef($_GET['id']);
                return $this->view->load("village/edit",$data);

        }
        public function delete(){
            //Instanciation du model
            $tdb = new VillageDB();
            $okkk=$tdb->deleteVillage($_GET['id']);
            $data['okkk'] = $okkk;
            $data['tests'] = $tdb->listeVillage();
            return $this->view->load("village/village",$data);

        }


        public function add(){
			//Instanciation du model
            $tdb = new VillageDB();
			//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                if(!empty($nv) && !empty($ncv) &&  !empty($pcv)  ) {
                    $ok = $tdb->addVillage($nv,$ncv,$pcv);
                    $data['ok'] = $ok;
                }
            }
            $data['tests'] = $tdb->listeVillage();
            return $this->view->load("village/village",$data);
        }
		public function update(){
			//Instanciation du model
            $tdb = new VillageDB();
            if(isset($_POST['modifier'])){
                extract($_POST);
                if(!empty($id) && !empty($nv) && !empty($ncv) &&  !empty($pcv)  )
                {
                    $okk = $tdb->updateVillage($id,$nv,$ncv,$pcv);
                    $data['okk'] = $okk;
                }
            }
            $data['tests'] = $tdb->listeVillage();
            return $this->view->load("village/village",$data);

        }
    }
?>