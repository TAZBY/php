<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class AbonnementDB extends Model{
		
		//La base de données samane_test est dans view/test
		//Pour tester importer la 
        public function __construct(){
            parent::__construct();
        }

        function getAbonnementRef($id)
        {
            $sql = "SELECT *
                     FROM abonnement
                     WHERE num_abonnement = $id";
            
			return $this->db->query($sql)->fetchAll();
        }
		
		function addAbonnement($date, $description,$idclient,$idcompteur){
			$sql = "INSERT INTO abonnement VALUES(null, '$date', '$description','$idclient','$idcompteur')";
			if($this->db != null)
			{
				$this->db->exec($sql);
				return $this->db->lastInsertId();//Si la clé primaire est auto_increment
											 //sinon return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
		function deleteAbonnement($id){
			$sql = "DELETE FROM abonnement WHERE num_abonnement = $id";

			return $this->db->exec($sql);
		}
		
		function updateAbonnement($id,$dateA, $description,$idclient,$idcompteur){
			$sql = "UPDATE abonnement SET date_abonnement = '$dateA',description_abonnement='$description',
                    id_client='$idclient',num_compteur='$idcompteur'
                    WHERE num_abonnement = $id";

			return $this->db->exec($sql);
		}
		
		function listeAbonnement(){
			$sql = "SELECT num_abonnement,date_abonnement,description_abonnement,CONCAT(nom_client,' ',prenom_client) as nc,compteur.num_compteur
			       FROM abonnement,client,compteur
			       WHERE abonnement.id_client=client.id and abonnement.num_compteur=compteur.id";
			if($this->db != null)
				return $this->db->query($sql)->fetchAll();
			else
				return null;
		}
        function RechAbonnement($nom_client){
            $sql = "SELECT num_abonnement,date_abonnement,description_abonnement,CONCAT(nom_client,' ',prenom_client) as nc,compteur.num_compteur
			       FROM abonnement,client,compteur
			       WHERE abonnement.id_client=client.id and abonnement.num_compteur=compteur.id and CONCAT(nom_client,' ',prenom_client) LIKE '%$nom_client%'";
            if($this->db != null)
                return $this->db->query($sql)->fetchAll();
            else
                return null;
        }
        function liste_Client(){
            $sql = "SELECT id,CONCAT(nom_client,' ',prenom_client) as nc
                   FROM client";
            if($this->db != null)
                return $this->db->query($sql)->fetchAll();
            else
                return null;
        }
        function liste_Compteur(){
            $sql = "SELECT id,num_compteur
                   FROM compteur";
            if($this->db != null)
                return $this->db->query($sql)->fetchAll();
            else
                return null;
        }
	}