<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
class ConsommationDB extends Model{

    //La base de donn�es samane_test est dans view/test
    //Pour tester importer la
    public function __construct(){
        parent::__construct();
    }

    function getConsoRef($num_conso)
    {
        $sql = "SELECT *
                     FROM consommation
                     WHERE num_conso = $num_conso";

        return $this->db->query($sql)->fetchAll();
    }

    function addConso( $id,$volume_cons,$volume_cons_lettre,$date_prelevement,$mois,$prix,$etat,$id_client){
        $sql = "INSERT INTO consommation VALUES(null, '$id','$volume_cons','$volume_cons_lettre','$date_prelevement','$mois','$prix','$etat','$id_client')";
        if($this->db != null)
        {
            $this->db->exec($sql);
            return $this->db->lastInsertId();//Si la cl� primaire est auto_increment
            //sinon return $this->db->exec($sql);
        }else{
            return null;
        }
    }

    function deleteConso($num_conso){
        $sql = "DELETE FROM consommation WHERE num_conso = $num_conso";

        return $this->db->exec($sql);
    }

    function updateConso($num_conso, $volume_cons,$volume_cons_lettre,$date_prelevement,$mois,$id){
        $sql = "UPDATE consommation SET volume_cons = '$volume_cons',
                            volume_cons_lettre= '$volume_cons_lettre',
                    date_prelevement='$date_prelevement',
                    mois='$mois',
                    id='$id'
                    WHERE num_conso = $num_conso";

        return $this->db->exec($sql);
    }


    function listeConso(){
        $sql = "SELECT num_conso,consommation.volume_cons,consommation.volume_cons_lettre,date_prelevement,mois,compteur.num_compteur
			       FROM consommation,compteur
			       WHERE consommation.id=compteur.id";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function RechConso($num_compteur){
        $sql = "SELECT num_conso,consommation.volume_cons,volume_cons_lettre,date_prelevement,mois,compteur.num_compteur
			       FROM consommation,compteur
			       WHERE consommation.id=compteur.id and compteur.num_compteur = '$num_compteur'";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function listeCompteur(){
        $sql = "SELECT id,num_compteur
                   FROM compteur";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function updateCmpteur($id, $volume_cons){
        $sql = "UPDATE compteur SET volume_cons = $volume_cons
                    WHERE id_compter = $id";

        return $this->db->exec($sql);
    }
    function liste_Client(){
        $sql = "SELECT id,CONCAT(nom_client,' ',prenom_client) as nc
                   FROM client";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
}