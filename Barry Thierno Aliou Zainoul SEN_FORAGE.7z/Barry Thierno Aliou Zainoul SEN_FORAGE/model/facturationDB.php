<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
class facturationDB extends Model{

    //La base de données samane_test est dans view/test
    //Pour tester importer la
    public function __construct(){
        parent::__construct();
    }

    function getFacturation($id_facture)
    {
        $sql = "SELECT *
                     FROM facturation
                     WHERE id_facture = $id_facture";

        return $this->db->query($sql)->fetchAll();
    }

    function addfacture($prix,$date_facturation,$num_abonnement,$num_conso){
        $sql = "INSERT INTO facturation VALUES(null, '$prix','$date_facturation',null,'$num_conso','$num_abonnement')";
        if($this->db != null)
        {
            $this->db->exec($sql);
            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
            //sinon return $this->db->exec($sql);
        }else{
            return null;
        }
    }
    function addreglement($montant,$numconso){
        $sql = "INSERT INTO reglement VALUES(null, '$montant','$numconso')";
        if($this->db != null)
        {
            $this->db->exec($sql);
            return $this->db->lastInsertId();//Si la clé primaire est auto_increment
            //sinon return $this->db->exec($sql);
        }else{
            return null;
        }
    }

    function deleteFacture($id_facture){
        $sql = "DELETE FROM facturation WHERE id_facture = $id_facture";

        return $this->db->exec($sql);
    }

    function updateFacture($id_facture, $prix,$date_facturation,$num_abonnement,$num_conso){
        $sql = "UPDATE facturation SET prix = '$prix',date_facturation='$date_facturation',
                    ,num_abonnement='$num_abonnement',num_conso='$num_conso'
                    WHERE id_facture = $id_facture";

        return $this->db->exec($sql);
    }

    function ListeFacture(){
        $sql = "SELECT num_conso,consommation.volume_cons,consommation.volume_cons_lettre,date_prelevement,mois,compteur.num_compteur,prix,etat,
                   CONCAT(nom_client,' ',prenom_client) as nc,num_abonnement
			       FROM consommation,compteur,client,abonnement
			       WHERE consommation.id=compteur.id and consommation.id_client=client.id and abonnement.num_compteur=compteur.id and etat!='reglee'";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function RechFacture($num_facture){
        $sql = "SELECT num_conso,consommation.volume_cons,consommation.volume_cons_lettre,date_prelevement,mois,compteur.num_compteur,prix,etat,
                   CONCAT(nom_client,' ',prenom_client) as nc,num_abonnement
			       FROM consommation,compteur,client,abonnement
			       WHERE consommation.id=compteur.id and consommation.id_client=client.id and abonnement.num_compteur=compteur.id and num_conso=$num_facture  and etat!='reglee'";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function Facture($num_facture){
        $sql = "SELECT num_conso,consommation.volume_cons,consommation.volume_cons_lettre,date_prelevement,mois,compteur.num_compteur,prix,adresse,num_telephone,
                   CONCAT(nom_client,' ',prenom_client) as nc,num_abonnement
			       FROM consommation,compteur,client,abonnement
			       WHERE consommation.id=compteur.id and consommation.id_client=client.id and abonnement.num_compteur=compteur.id and num_conso=$num_facture";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function liste_Client(){
        $sql = "SELECT id,CONCAT(nom_client,' ',prenom_client) as nc
                   FROM client";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function liste_Compteur(){
        $sql = "SELECT id,num_compteur
                   FROM compteur";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function listeAbonnement(){
        $sql = "SELECT num_abonnement,concat(nom_client, ' ',prenom_client) as nc
                   FROM abonnement,client where abonnement.id_client=client.id ";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function listeConso(){
        $sql = "SELECT num_conso,num_compteur
                   FROM consommation,compteur
                   where consommation.id=compteur.id";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }
    function getFactureRef($id)
    {
        $sql = "SELECT num_conso
                     FROM consommation
                     WHERE num_conso = $id";

        return $this->db->query($sql)->fetchAll();
    }
    function updateConsommation($num_conso, $etat){
        $sql = "UPDATE consommation SET etat = '$etat'
                    WHERE num_conso = $num_conso";

        return $this->db->exec($sql);
    }
    function listeReglement(){
        $sql = "SELECT num_conso,num_compteur
                   FROM consommation,compteur
                   where consommation.id=compteur.id";
        if($this->db != null)
            return $this->db->query($sql)->fetchAll();
        else
            return null;
    }

}