<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class CompteurDB extends Model{
		
		//La base de données samane_test est dans view/test
		//Pour tester importer la 
        public function __construct(){
            parent::__construct();
        }

        function getCompteurRef($id)
        {
            $sql = "SELECT *
                     FROM compteur
                     WHERE id = $id";
            
			return $this->db->query($sql)->fetchAll();
        }
		
		function addCompteur($numcompteur){
			$sql = "INSERT INTO compteur VALUES(null,'$numcompteur')";
			if($this->db != null)
			{
				$this->db->exec($sql);
                return $this->db->lastInsertId();;//Si la clé primaire est auto_increment
											 //sinon return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
		function deleteCompteur($id){
			$sql = "DELETE FROM compteur WHERE id = $id";

			return $this->db->exec($sql);
		}
		
		function updateCompteur($id,$numc){
			$sql = "UPDATE compteur SET num_compteur = '$numc'
                    WHERE id = $id";

			return $this->db->exec($sql);
		}
		
		function listeCompteur(){
			$sql = "SELECT *
                    FROM compteur";
			if($this->db != null)
				return $this->db->query($sql)->fetchAll();
			else
				return null;
		}
        function RechCompteur($num_compteur){
            $sql = "SELECT *
                    FROM compteur
			       WHERE num_compteur LIKE '%$num_compteur%'";
            if($this->db != null)
                return $this->db->query($sql)->fetchAll();
            else
                return null;
        }

	}