<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class VillageDB extends Model{
		
		//La base de données samane_test est dans view/test
		//Pour tester importer la 
        public function __construct(){
            parent::__construct();
        }

        function getVillageRef($id)
        {
            $sql = "SELECT *
                     FROM village
                     WHERE id_village = $id";
            
			return $this->db->query($sql)->fetchAll();
        }
		
		function addVillage($nomvillage, $nomchefvillage,$prenomchefvillage){
			$sql = "INSERT INTO village VALUES(null, '$nomvillage', '$nomchefvillage','$prenomchefvillage')";
			if($this->db != null)
			{
				$this->db->exec($sql);
				return $this->db->lastInsertId();//Si la clé primaire est auto_increment
											 //sinon return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
		function deleteVillage($id){
			$sql = "DELETE FROM village WHERE id_village = $id";

			return $this->db->exec($sql);
		}
		
		function updateVillage($id,$nomvillage, $nomchefvillage,$prenomchefvillage){
			$sql = "UPDATE village SET nom_village = '$nomvillage',nom_chefvillage='$nomchefvillage',
                    prenom_chefvillage='$prenomchefvillage'
                    WHERE id_village = $id";

			return $this->db->exec($sql);
		}
		
		function listeVillage(){
			$sql = "SELECT *
                    FROM village";
			if($this->db != null)
				return $this->db->query($sql)->fetchAll();
			else
				return null;
		}
        function RechVillage($nom_village){
            $sql = "SELECT *
                    FROM village
			       WHERE nom_village LIKE '%$nom_village%'";
            if($this->db != null)
                return $this->db->query($sql)->fetchAll();
            else
                return null;
        }

	}