<?php
/* Smarty version 3.1.30, created on 2018-03-08 17:52:52
  from "C:\xampp\htdocs\mesprojets\Barry Thierno Aliou Zainoul SEN_FORAGE\view\facturation\facture.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5aa16a64f3ba74_63795818',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '647fca76a1b287acd037ed51a1f15903a4dce4ae' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\Barry Thierno Aliou Zainoul SEN_FORAGE\\view\\facturation\\facture.html',
      1 => 1520523205,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5aa16a64f3ba74_63795818 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>FACTURE</title>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap-cerulean.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
</head>
<style>
   .logo {
       font-family: Helvetica;
       font-size: 14px;
       width: 45%;
   }
   .info {
       margin-left: 70%;
       margin-top: -15%;
       font-family: Helvetica;
       font-size: 18px;
       width: 45%;
   }
   .montant {

       margin-left: 30%;
       margin-top: 120px;
       font-family: Helvetica;
       font-size: 28px;
       width: 70%;
   }
</style>

<body onload="window.print()">
<br/>
<br/>
<div class="logo" >
    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" width="100" height="100"><br/>
    <tr>ENTREPRISE DE PRODUCTION ET DE DISTRIBUTION D'EAU</tr><br />
    <tr>Adresse Dakar, Mermoz </tr><br />
    <tr><em>Tel:33 822 38 37/ +221 77 551 99 51</em></tr><br />
    <tr><em>+221 77 436 52 64 / +221 76 534 37 74</em></tr><br />
    <tr><strong>NINEA:00628 1921-1A1-RCCM SN DK 2017 A6533</strong></tr><br />
    <tr><em>Email:senforage@gmail.com</em></tr><br />
</div>
<div class="info" >
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
    <tr>Client : <?php echo $_smarty_tpl->tpl_vars['test']->value['nc'];?>
</tr><br />
    <tr><em>Adresse:<?php echo $_smarty_tpl->tpl_vars['test']->value['adresse'];?>
</em></tr><br />
    <tr><em>Telephone: <?php echo $_smarty_tpl->tpl_vars['test']->value['num_telephone'];?>
</em></tr><br />
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


</div>
<div class="montant" >
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
    <tr class="nf">Numero Facture: <?php echo $_smarty_tpl->tpl_vars['test']->value['num_conso'];?>
</tr><br />
    <tr class="mf">Montant de la facture :<?php echo $_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix'];?>
 FCFA</em></tr><br />
    <tr class="ar">Arrieres : <?php echo $_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix']-$_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix'];?>
</em></tr><br />
    <tr class="ar">NET A PAYER:<?php echo $_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix']+($_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix']-$_smarty_tpl->tpl_vars['test']->value['volume_cons']*$_smarty_tpl->tpl_vars['test']->value['prix']);?>
FCFA</tr><br />

    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>


</div>
</body>
</html><?php }
}
