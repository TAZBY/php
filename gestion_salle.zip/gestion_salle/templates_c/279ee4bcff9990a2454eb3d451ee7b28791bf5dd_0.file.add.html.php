<?php
/* Smarty version 3.1.30, created on 2018-04-05 17:25:28
  from "C:\xampp\htdocs\mesprojets\gestion_salle\view\creneau\add.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac63fe8a00998_96393638',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '279ee4bcff9990a2454eb3d451ee7b28791bf5dd' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\gestion_salle\\view\\creneau\\add.html',
      1 => 1522938983,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac63fe8a00998_96393638 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>

    <meta charset="UTF-8">
    <title>page liste</title>
    <!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
</head>
<style>
    .footer {
        margin-top: 20px;
        left: 0;
        bottom: 0;
        width: 100%;
        height:60px;
        background-color:#011d37;
        color: white;
        text-align:center;

    }
</style>
<div class="container">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/index">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" alt="Logo" class="img-thumbnail" style="width:80px;">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/add">Ajouter une salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/liste"> Liste des salles</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/addClasse">Ajouter une classe</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/liste">Liste des classes</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">Occuper une Salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/Liste">Liste des salles occuppees</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="">
    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logoiam.png" alt="logo" style=";
    min-width: 70%;
    min-height: 10%;
    height: 150px;" class="img-responsive center-block"/>
</div>
<br>
<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire D'ajout</div>
        <div class="panel-body">
            <?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
            <?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
            <div class="panel-body" style="color: green; background-color: #afd9ee">
                Creneau ajouté avec succes!
            </div>
            <?php } else { ?>
            Erreur d'insertion!
            <?php }?>
            <?php }?>
            <form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Classe</label>
                    <select class="form-control" id="exampleFormControlSelect1" name="idclasse">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['classes']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['idclasse'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nomclasse'];?>
</option>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>
                </div>
                <div class="form-group col-md-6 ">
                    <label for="exampleFormControlSelect1">Nom salle</label>
                    <select class="form-control" id="d" name="idsalle">
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['salles']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
                        <option value="<?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
"><?php echo $_smarty_tpl->tpl_vars['v']->value['nom'];?>
</option>
                        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

                    </select>
                </div>
                <div class="form-group col-md-12">
                    <label class="control-label">Date</label>
                    <input class="form-control" type="date" name="datecre"/>

                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure debut</label>
                    <input class="form-control" type="time" name="hd"/>
                </div>
                <div class="form-group col-md-6">
                    <label for="exampleFormControlSelect1">Heure fin</label>
                    <input class="form-control" type="time" name="hf"/>
                </div>
                <div class="form-group col-md-12">
                    <input class="btn btn-success" type="submit" name="valider" value="Valider"/>
                    <input class="btn btn-danger" type="reset" name="annuler" value="Annuler"/>
                </div>
            </form>
        </div>
    </div>
</div>
<!--<div class="footer">-->
    <!--<br/>-->
    <!--<p>@2018 copyright all rights reserved Gestion de Salle Groupe IAM</p>-->
    <!--<br/>-->
<!--</div>-->
</body>
</html><?php }
}
