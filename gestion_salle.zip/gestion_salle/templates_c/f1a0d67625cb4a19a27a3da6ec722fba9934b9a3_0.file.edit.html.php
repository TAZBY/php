<?php
/* Smarty version 3.1.30, created on 2018-04-05 17:39:02
  from "C:\xampp\htdocs\mesprojets\gestion_salle\view\salle\edit.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5ac64316736579_70684043',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f1a0d67625cb4a19a27a3da6ec722fba9934b9a3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mesprojets\\gestion_salle\\view\\salle\\edit.html',
      1 => 1522939007,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ac64316736579_70684043 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout D'une Salle</title>
    <link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
    <?php echo '<script'; ?>
 language="JavaScript">
        function check(){
            if(document.getElementById("tableau").checked=true){
                document.getElementById("proj").checked=true;
            }

        }

    <?php echo '</script'; ?>
>

</head>
<body>
<div class="container">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
accueil/index">
                    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.png" alt="Logo" class="img-thumbnail" style="width:80px;">
                </a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/add">Ajouter une salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/liste"> Liste des salles</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/addClasse">Ajouter une classe</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Classe/liste">Liste des classes</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/add">Occuper une Salle</a></li>
                    <li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Creneau/Liste">Liste des salles occuppees</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<div class="">
    <img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logoiam.png" alt="logo" style=";
    min-width: 70%;
    min-height: 10%;
    height: 150px;" class="img-responsive center-block"/>
</div>
<br>
<div class="container col-md-6 col-lg-6 col-sm-6 col-md-offset-3">
    <div class="panel panel-info">
        <div class="panel-heading">Formulaire de modification de Salles</div>
        <div class="panel-body">
            <form name="form1" method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Salle/update">
                <div>
                    <label class="control-label ">Nom Salle</label>
                    <input class="form-control" type="text" name="nom" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['nom'];?>
"/>
                    <div class="row">
                        <legend class="col-form-legend col-sm-2">Taille</legend>
                        <div class="col-sm-10">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="taille"  value="<?php echo $_smarty_tpl->tpl_vars['test']->value['taille'];?>
"/>
                                    Petite Salle
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="taille"  value="<?php echo $_smarty_tpl->tpl_vars['test']->value['taille'];?>
"/>
                                    Salle Moyenne
                                </label>
                            </div>
                            <div class="form-check disabled">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="taille" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['taille'];?>
"/>
                                    Grande Salle
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Niveau</label>
                        <select class="form-control" id="" name="niveausalle" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['niveausalle'];?>
">
                            <option selected>Choisissez...</option>
                            <option>RDC</option>
                            <option value="1er niveau">1er Niveau</option>
                            <option value="2eme niveau">2eme Niveau</option>
                            <option value="3eme niveau">3eme Niveau</option>
                            <option value="4eme niveau">4eme Niveau</option>
                            <option value="5eme niveau">5eme Niveau</option>
                            <option value="6eme niveau">6eme Niveau</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Type De Salle</label>
                        <select class="form-control" name="typesalle" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['typesalle'];?>
">
                            <option selected>Choisissez...</option>
                            <option value="Salle de TP">Sallle De TP</option>
                            <option value="Salle de Conference">Salle de Conference</option>
                            <option value="Amphitheatre">Amphitheatre</option>
                            <option value="Salle Normale">Salle Normal</option>
                        </select>
                    </div>
                    <div class="row">
                        <legend class="col-form-legend col-sm-2">Tableau</legend>
                        <div class="col-sm-10">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" name="tableau" id="tableau"
                                            value="<?php echo $_smarty_tpl->tpl_vars['test']->value['tableau'];?>
"/>
                                    Smart Board
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="checkbox" name="tableau"  value="<?php echo $_smarty_tpl->tpl_vars['test']->value['tableau'];?>
"/>
                                    A Marqueur
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <legend class="col-form-legend col-sm-2">Projecteur</legend>
                        <div class="col-sm-10">
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="videoprojecteur"  value="<?php echo $_smarty_tpl->tpl_vars['test']->value['videoprojecteur'];?>
"/>
                                    oui
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input class="form-check-input" type="radio" name="videoprojecteur" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['videoprojecteur'];?>
"/>
                                    non
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Batiment</label>
                        <select class="form-control"  name="batiment" value="<?php echo $_smarty_tpl->tpl_vars['test']->value['batiment'];?>
">
                            <option selected>Choisissez...</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="E">E</option>
                            <option value="F">F</option>
                        </select>
                    </div>
                </div>
                <input class="btn btn-success" type="submit" value="modifier" name="editsalle"/>
                <input class="btn btn-danger" type="reset" value="Annuler" name="annuler"/>
            </form>
        </div>
    </div>
</div>
</body>
</html><?php }
}
